// v8.6 System Toast Adapter
// Prefer importing this from pages/components to avoid touching shadcn internals.

export { useToast, toast } from '@/components/ui/use-toast';
