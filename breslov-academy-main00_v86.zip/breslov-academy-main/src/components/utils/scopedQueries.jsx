
// ADAPTER: Re-exports from canonical scoped API module
// This file preserved for backwards compatibility
// DO NOT modify helpers here - modify in components/api/scoped.js

export * from '../api/scoped';
