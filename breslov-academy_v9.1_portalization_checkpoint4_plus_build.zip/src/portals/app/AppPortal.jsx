import React, { Suspense } from 'react';
import { Route, Routes, useParams, Navigate } from 'react-router-dom';
import PageNotFound from '@/lib/PageNotFound';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { useAuth } from '@/lib/AuthContext';
import { useSession } from '@/components/hooks/useSession';
import OnboardingHub from './OnboardingHub';
import { pagesConfig } from '@/pages.config';

const RouteFallback = ({ label = 'Loading…' }) => (
  <div className="fixed inset-0 flex items-center justify-center">
    <div className="flex flex-col items-center gap-3">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      <div className="text-sm text-slate-500">{label}</div>
    </div>
  </div>
);

const AppIndexRedirect = () => {
  const { role, memberships, needsSchoolSelection, isLoading } = useSession();
  const urlParams = new URLSearchParams(window.location.search);
  const loginRole = urlParams.get('loginRole');

  if (isLoading) return <RouteFallback label="Loading session…" />;

  if (!memberships || memberships.length === 0) {
    return <Navigate to="onboarding" replace />;
  }

  if (needsSchoolSelection) {
    return <Navigate to="SchoolSelect" replace />;
  }

  const isTeacherHint = loginRole === 'teacher' || loginRole === 'admin';
  const isTeacher = role === 'TEACHER' || role === 'ADMIN' || role === 'OWNER';

  return <Navigate to={(isTeacher || isTeacherHint) ? "teach" : "dashboard"} replace />;
};

const { Pages, Layout } = pagesConfig;

const LayoutWrapper = ({ children, currentPageName }) => Layout
  ? <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

// Case-insensitive / legacy route support inside the app portal.
const DynamicPageRoute = ({ fallbackLabel = 'Loading page…' }) => {
  const { pageName } = useParams();
  const seg = (pageName || '').trim();
  const matchKey = Object.keys(Pages).find((k) => k.toLowerCase() === seg.toLowerCase());
  if (!matchKey) return <PageNotFound />;
  const Page = Pages[matchKey];
  return (
    <LayoutWrapper currentPageName={matchKey}>
      <Suspense fallback={<RouteFallback label={fallbackLabel} />}>
        <Page />
      </Suspense>
    </LayoutWrapper>
  );
};

/**
 * Authenticated application portal.
 * Mounted at /app/*.
 */
export default function AppPortal() {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    }
    if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      {/* /app */}
      <Route index element={<AppIndexRedirect />} />

      {/* Onboarding */}
      <Route path="onboarding" element={<OnboardingHub />} />

      {/* Canonical quiz routes */}
      <Route path="my-quizzes" element={<Pages.MyQuizzes />} />
      <Route path="quiz/:quizId" element={<Pages.QuizTake />} />
      <Route path="teach/quizzes" element={<Pages.TeachQuizzes />} />
      <Route path="teach/quizzes/new" element={<Pages.TeachQuizEditor />} />
      <Route path="teach/quizzes/:quizId" element={<Pages.TeachQuizEditor />} />

      {/* Legacy /PageName routes (scoped under /app) */}
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={path}
          element={
            <LayoutWrapper currentPageName={path}>
              <Suspense fallback={<RouteFallback label="Loading page…" />}>
                <Page />
              </Suspense>
            </LayoutWrapper>
          }
        />
      ))}

      {/* Lowercase / registry aliases like /app/dashboard, /app/vault, etc. */}
      <Route path=":pageName" element={<DynamicPageRoute />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}
