import React from 'react';
import { PublicContentPage } from '@/portals/public/components/PublicContentPage';

export default function LegalPrivacy() {
  return <PublicContentPage routeKey="/privacy" />;
}
