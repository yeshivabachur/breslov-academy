import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

/**
 * Preserves all legacy deep links by redirecting them to the app portal.
 *
 * Examples:
 * - /Dashboard -> /app/Dashboard
 * - /teach/quizzes -> /app/teach/quizzes
 * - /my-quizzes -> /app/my-quizzes
 */
export default function LegacyToAppRedirect() {
  const loc = useLocation();
  const pathname = loc.pathname || '/';
  if (pathname.startsWith('/app')) {
    // Avoid loops; if we got here, the path is likely invalid.
    return <Navigate to="/app" replace />;
  }
  const target = `/app${pathname === '/' ? '' : pathname}${loc.search || ''}${loc.hash || ''}`;
  return <Navigate to={target} replace />;
}
