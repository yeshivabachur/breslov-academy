import React, { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Crown, Sparkles, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { normalizeCourseAccessLevel } from '@/components/utils/entitlements';

function legacyTierAccess(course, userTier) {
  const tier = String(course?.access_tier || 'free').toLowerCase();
  const ut = String(userTier || 'free').toLowerCase();
  return (
    tier === 'free' ||
    (tier === 'premium' && ['premium', 'elite'].includes(ut)) ||
    (tier === 'elite' && ut === 'elite')
  );
}

export default function CourseCard({ course, userTier = 'free', hasAccess: hasAccessProp }) {
  const accessLevel = useMemo(() => normalizeCourseAccessLevel(course), [course]);
  const hasAccess = hasAccessProp ?? legacyTierAccess(course, userTier);

  const tierIcons = {
    FREE: { icon: Sparkles, color: 'text-slate-500' },
    PAID: { icon: Crown, color: 'text-blue-500' },
    PRIVATE: { icon: Lock, color: 'text-amber-600' },
  };

  const Icon = tierIcons[accessLevel]?.icon || Sparkles;
  const iconColor = tierIcons[accessLevel]?.color || 'text-slate-500';

  const levelColors = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-yellow-100 text-yellow-800',
    advanced: 'bg-red-100 text-red-800',
  };

  const accessLabel = accessLevel === 'FREE' ? 'Free' : accessLevel === 'PRIVATE' ? 'Private' : 'Paid';

  return (
    <Link to={createPageUrl(`CourseDetail?id=${course.id}`)}>
      <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300 border-0 bg-white">
        <div className="relative h-48 overflow-hidden">
          {course.image_url ? (
            <img
              src={course.image_url}
              alt={course.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Icon className={`w-16 h-16 ${iconColor} opacity-50`} />
            </div>
          )}

          {!hasAccess && (
            <div className="absolute inset-0 bg-slate-900/80 flex items-center justify-center">
              <div className="text-center">
                <Lock className="w-10 h-10 text-amber-300 mx-auto mb-2" />
                <p className="text-white font-semibold">Access Required</p>
              </div>
            </div>
          )}

          <Badge className="absolute top-3 right-3 bg-white/90 text-slate-900">
            {accessLabel}
          </Badge>
        </div>

        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <h3 className="font-bold text-slate-900 text-lg line-clamp-2 flex-1">
              {course.title}
            </h3>
          </div>

          <p className="text-sm text-slate-600 mb-4 line-clamp-2">
            {course.description}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className={levelColors[course.level]}>
                {course.level}
              </Badge>
              {course.duration && (
                <div className="flex items-center text-sm text-slate-500">
                  <Clock className="w-4 h-4 mr-1" />
                  {course.duration}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 text-sm text-slate-500">
              {course.lessons_count ? (
                <span>{course.lessons_count} lessons</span>
              ) : null}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
