import React, { useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { BookOpen, Crown, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import StatCard from '@/components/dashboard/StatCard';
import CourseCard from '@/components/courses/CourseCard';
import CourseRecommendations from '@/components/ai/CourseRecommendations';
import LearningInsights from '@/components/insights/LearningInsights';
import AnnouncementsPanel from '@/components/announcements/AnnouncementsPanel';
import { useSession } from '@/components/hooks/useSession';
import {
  canUserAccessCourseSync,
  hasAllCoursesEntitlement,
  isEntitlementActive,
} from '@/components/utils/entitlements';

export default function Dashboard() {
  const { user, role, activeSchoolId, isLoading } = useSession();

  const { data: entitlementsRaw = [] } = useQuery({
    queryKey: ['entitlements', activeSchoolId, user?.email],
    queryFn: async () => {
      if (!activeSchoolId || !user?.email) return [];
      return base44.entities.Entitlement.filter(
        { school_id: activeSchoolId, user_email: user.email },
        '-created_date',
        250,
      );
    },
    enabled: !!activeSchoolId && !!user?.email,
    staleTime: 30_000,
  });

  const activeEntitlements = useMemo(
    () => (entitlementsRaw || []).filter((e) => isEntitlementActive(e)),
    [entitlementsRaw],
  );

  const userTier = useMemo(() => {
    const r = String(role || '').toUpperCase();
    if (['OWNER', 'ADMIN', 'INSTRUCTOR', 'TEACHER'].includes(r)) return 'elite';
    if (hasAllCoursesEntitlement(activeEntitlements)) return 'premium';
    return 'free';
  }, [role, activeEntitlements]);

  const tierBenefits = {
    free: { name: 'Free', color: 'text-slate-200', icon: Star },
    premium: { name: 'Premium', color: 'text-blue-200', icon: Crown },
    elite: { name: 'Elite', color: 'text-amber-200', icon: Crown },
  };

  const currentTier = tierBenefits[userTier] || tierBenefits.free;

  const { data: courses = [], isLoading: isLoadingCourses } = useQuery({
    queryKey: ['dashboard-courses', activeSchoolId],
    queryFn: async () => {
      if (!activeSchoolId) return [];
      let schoolCourses = await base44.entities.Course.filter(
        { is_published: true, school_id: activeSchoolId },
        '-created_date',
        6,
      );

      // Fallback to legacy school if no courses
      if (schoolCourses.length === 0) {
        const legacySchools = await base44.entities.School.filter({ slug: 'legacy' });
        if (legacySchools.length > 0) {
          schoolCourses = await base44.entities.Course.filter(
            { is_published: true, school_id: legacySchools[0].id },
            '-created_date',
            6,
          );
        }
      }

      return schoolCourses;
    },
    enabled: !!activeSchoolId,
  });

  const { data: progress = { courseProgress: [], insights: [] } } = useQuery({
    queryKey: ['progress', activeSchoolId, user?.email],
    queryFn: async () => {
      if (!user?.email) return { courseProgress: [], insights: [] };
      const courseProgress = await base44.entities.UserProgress.filter({ user_email: user.email }, '-created_date', 500);
      const insights = await base44.entities.LearningInsight.filter({ user_email: user.email, is_read: false }, '-created_date', 100);
      return { courseProgress, insights };
    },
    enabled: !!user?.email,
  });

  const completedLessons = progress?.courseProgress?.filter((p) => p.completed).length || 0;
  const inProgressCourses = [
    ...new Set(
      (progress?.courseProgress || [])
        .filter((p) => !p.completed)
        .map((p) => p.course_id)
        .filter(Boolean),
    ),
  ].length;

  const unreadInsights = progress?.insights?.length || 0;

  if (isLoading) {
    return <div className="space-y-8"><div className="text-slate-600">Loading…</div></div>;
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-white mb-6 md:mb-0">
            <h1 className="text-4xl font-bold mb-2">Shalom, {user?.full_name || 'Student'}</h1>
            <p className="text-slate-300 text-lg">Continue your journey through the teachings of Rebbe Nachman</p>
            <div className="flex items-center space-x-2 mt-4">
              {React.createElement(currentTier.icon, { className: `w-5 h-5 ${currentTier.color}` })}
              <span className={`font-semibold ${currentTier.color}`}>{currentTier.name} Member</span>
            </div>
          </div>

          {userTier === 'free' && (
            <Link to={createPageUrl('Subscription')}>
              <Button className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold px-8 py-6 text-lg shadow-xl">
                <Crown className="w-5 h-5 mr-2" />
                Upgrade to Premium
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Announcements */}
      <AnnouncementsPanel />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          icon={BookOpen}
          title="Lessons Completed"
          value={completedLessons}
          description="Total completed lessons"
        />
        <StatCard
          icon={BookOpen}
          title="Courses In Progress"
          value={inProgressCourses}
          description="Courses you're currently studying"
        />
        <StatCard
          icon={Star}
          title="New Insights"
          value={unreadInsights}
          description="Unread learning insights"
        />
      </div>

      {/* Insights */}
      <LearningInsights user={user} insights={progress?.insights || []} />

      {/* Featured Courses */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-900">Featured Courses</h2>
          <Link to={createPageUrl('Courses')}>
            <Button variant="outline">View all</Button>
          </Link>
        </div>

        {isLoadingCourses ? (
          <div className="text-slate-600">Loading courses…</div>
        ) : courses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                hasAccess={canUserAccessCourseSync(course, role, activeEntitlements)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl border-2 border-dashed border-slate-300">
            <BookOpen className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 text-lg">No courses available yet</p>
            <p className="text-slate-500 text-sm mt-2">Check back soon for new Torah content</p>
          </div>
        )}
      </div>

      {/* Recommendations */}
      <CourseRecommendations
        user={user}
        userProgress={progress?.courseProgress || []}
        courses={courses}
        role={role}
        activeEntitlements={activeEntitlements}
      />
    </div>
  );
}
