import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Search } from 'lucide-react';
import CourseCard from '@/components/courses/CourseCard';
import AdvancedSearch from '@/components/search/AdvancedSearch';
import { useSession } from '@/components/hooks/useSession';
import { canUserAccessCourseSync, isEntitlementActive } from '@/components/utils/entitlements';

export default function Courses() {
  const { user, role, activeSchoolId: sessionSchoolId, isLoading: isLoadingSession } = useSession();
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [activeSchoolId, setActiveSchoolId] = useState(sessionSchoolId || null);

  useEffect(() => {
    // fallback for legacy flows
    const stored = localStorage.getItem('active_school_id');
    setActiveSchoolId(sessionSchoolId || stored || null);
  }, [sessionSchoolId]);

  const { data: courses = [], isLoading } = useQuery({
    queryKey: ['courses', activeSchoolId],
    queryFn: async () => {
      if (!activeSchoolId) return [];
      let schoolCourses = await base44.entities.Course.filter({
        is_published: true,
        school_id: activeSchoolId,
      }, 'sort_order');

      // Fallback to legacy school if no courses found
      if (schoolCourses.length === 0) {
        const legacySchools = await base44.entities.School.filter({ slug: 'legacy' });
        if (legacySchools.length > 0) {
          schoolCourses = await base44.entities.Course.filter({
            is_published: true,
            school_id: legacySchools[0].id,
          }, 'sort_order');
        }
      }

      return schoolCourses;
    },
    enabled: !!activeSchoolId && !isLoadingSession,
  });

  const { data: entitlementsRaw = [] } = useQuery({
    queryKey: ['entitlements', activeSchoolId, user?.email],
    queryFn: async () => {
      if (!activeSchoolId || !user?.email) return [];
      return base44.entities.Entitlement.filter({ school_id: activeSchoolId, user_email: user.email }, '-created_date', 250);
    },
    enabled: !!activeSchoolId && !!user?.email,
    staleTime: 30_000,
  });

  const activeEntitlements = useMemo(
    () => (entitlementsRaw || []).filter((e) => isEntitlementActive(e)),
    [entitlementsRaw],
  );

  useEffect(() => {
    setFilteredCourses(courses);
  }, [courses]);

  const handleFilter = (filtered) => {
    setFilteredCourses(filtered);
  };

  if (isLoadingSession) {
    return <div className="space-y-8"><div><h1 className="text-4xl font-bold text-slate-900 mb-2">Course Library</h1><p className="text-slate-600 text-lg">Loading…</p></div></div>;
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Course Library</h1>
        <p className="text-slate-600 text-lg">
          Explore the wisdom of Rebbe Nachman through our comprehensive courses
        </p>
      </div>

      {/* Advanced Search */}
      <AdvancedSearch courses={courses} onFilter={handleFilter} />

      {/* Results */}
      <div>
        <p className="text-slate-600 mb-6">
          Showing {filteredCourses.length} course{filteredCourses.length !== 1 ? 's' : ''}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              hasAccess={canUserAccessCourseSync(course, role, activeEntitlements)}
            />
          ))}
        </div>

        {filteredCourses.length === 0 && !isLoading && (
          <div className="text-center py-16 bg-white rounded-xl border-2 border-dashed border-slate-300">
            <Search className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 text-lg font-semibold mb-2">No courses found</p>
            <p className="text-slate-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </div>
    </div>
  );
}
