import React, { useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, CheckCircle, Crown, BookOpen, ArrowRight, Lock } from 'lucide-react';
import { useSession } from '@/components/hooks/useSession';
import {
  canUserAccessCourseSync,
  hasAllCoursesEntitlement,
  isEntitlementActive,
  normalizeCourseAccessLevel,
} from '@/components/utils/entitlements';

function normalizePathAccessLevel(path) {
  const level = String(path?.access_level || '').toUpperCase();
  if (level) return level;
  const tier = String(path?.access_tier || '').toLowerCase();
  if (tier === 'free') return 'FREE';
  if (tier) return 'PAID';
  return 'FREE';
}

export default function LearningPaths() {
  const { user, role, activeSchoolId, isLoading } = useSession();

  const { data: entitlementsRaw = [] } = useQuery({
    queryKey: ['entitlements', activeSchoolId, user?.email],
    queryFn: async () => {
      if (!activeSchoolId || !user?.email) return [];
      return base44.entities.Entitlement.filter({ school_id: activeSchoolId, user_email: user.email }, '-created_date', 250);
    },
    enabled: !!activeSchoolId && !!user?.email,
    staleTime: 30_000,
  });

  const activeEntitlements = useMemo(
    () => (entitlementsRaw || []).filter((e) => isEntitlementActive(e)),
    [entitlementsRaw],
  );

  const { data: paths = [] } = useQuery({
    queryKey: ['learning-paths', activeSchoolId],
    queryFn: () => base44.entities.LearningPath.filter({ is_published: true }, '-created_date', 200),
  });

  const { data: courses = [] } = useQuery({
    queryKey: ['courses', activeSchoolId],
    queryFn: async () => {
      if (!activeSchoolId) return [];
      let schoolCourses = await base44.entities.Course.filter({ is_published: true, school_id: activeSchoolId }, '-created_date', 500);

      if (schoolCourses.length === 0) {
        const legacySchools = await base44.entities.School.filter({ slug: 'legacy' });
        if (legacySchools.length > 0) {
          schoolCourses = await base44.entities.Course.filter({ is_published: true, school_id: legacySchools[0].id }, '-created_date', 500);
        }
      }

      return schoolCourses;
    },
    enabled: !!activeSchoolId,
  });

  const { data: progress = [] } = useQuery({
    queryKey: ['progress', activeSchoolId, user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user.email }, '-created_date', 2000),
    enabled: !!user?.email,
  });

  const isPrivileged = ['OWNER', 'ADMIN', 'INSTRUCTOR', 'TEACHER'].includes(String(role || '').toUpperCase());

  const hasPathAccess = (path) => {
    if (isPrivileged) return true;
    const level = normalizePathAccessLevel(path);
    if (level === 'FREE') return true;
    return hasAllCoursesEntitlement(activeEntitlements);
  };

  const calculateProgress = (path) => {
    const pathCourses = courses.filter((c) => (path.course_ids || []).includes(c.id));
    let completedCount = 0;

    pathCourses.forEach((course) => {
      const courseLessons = progress.filter((p) => p.course_id === course.id);
      const completedLessons = courseLessons.filter((p) => p.completed).length;
      if (courseLessons.length > 0 && completedLessons === courseLessons.length) {
        completedCount++;
      }
    });

    return pathCourses.length > 0 ? Math.round((completedCount / pathCourses.length) * 100) : 0;
  };

  const levelColors = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-yellow-100 text-yellow-800',
    advanced: 'bg-red-100 text-red-800',
  };

  if (isLoading) {
    return <div className="text-slate-600">Loading…</div>;
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Learning Paths</h1>
        <p className="text-slate-600 text-lg">
          Structured journeys to guide your learning through Rebbe Nachman's teachings
        </p>
      </div>

      {/* Paths Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {paths.map((path) => {
          const access = hasPathAccess(path);
          const pathCourses = courses.filter((c) => (path.course_ids || []).includes(c.id));
          const progressPercent = calculateProgress(path);

          return (
            <Card key={path.id} className="overflow-hidden hover:shadow-2xl transition-all group">
              <div className="relative h-48 bg-gradient-to-br from-purple-600 via-pink-500 to-orange-500">
                {path.thumbnail_url ? (
                  <img
                    src={path.thumbnail_url}
                    alt={path.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <MapPin className="w-20 h-20 text-white opacity-50" />
                  </div>
                )}

                {!access && (
                  <div className="absolute inset-0 bg-slate-900/70 flex items-center justify-center">
                    <div className="text-center text-white">
                      <Lock className="w-10 h-10 mx-auto mb-2 text-amber-300" />
                      <p className="font-semibold">Premium Access Required</p>
                    </div>
                  </div>
                )}

                <Badge className="absolute top-3 right-3 bg-white/90 text-slate-900">
                  {normalizePathAccessLevel(path) === 'FREE' ? 'Free' : 'Premium'}
                </Badge>
              </div>

              <CardHeader>
                <CardTitle className="text-2xl flex items-center justify-between">
                  <span>{path.title}</span>
                  {progressPercent === 100 && <CheckCircle className="w-6 h-6 text-green-500" />}
                </CardTitle>
                <p className="text-slate-600">{path.description}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Meta */}
                <div className="flex items-center gap-4 text-sm text-slate-600">
                  <div className="flex items-center">
                    <BookOpen className="w-4 h-4 mr-1" />
                    {pathCourses.length} courses
                  </div>
                  {path.duration && (
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {path.duration}
                    </div>
                  )}
                </div>

                {/* Course chips */}
                <div className="flex flex-wrap gap-2">
                  {pathCourses.slice(0, 6).map((c) => {
                    const courseAccess = canUserAccessCourseSync(c, role, activeEntitlements);
                    const label = c.title?.length > 22 ? `${c.title.slice(0, 22)}…` : c.title;
                    return (
                      <Badge
                        key={c.id}
                        variant="secondary"
                        className={`${levelColors[c.level] || ''} ${courseAccess ? '' : 'opacity-60'}`}
                        title={courseAccess ? 'Accessible' : 'Locked'}
                      >
                        {label}
                      </Badge>
                    );
                  })}
                  {pathCourses.length > 6 && (
                    <Badge variant="secondary">+{pathCourses.length - 6} more</Badge>
                  )}
                </div>

                {/* Progress bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-slate-600">
                    <span>Progress</span>
                    <span>{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-purple-600 to-pink-500 h-2 rounded-full transition-all"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Action */}
                <div className="pt-2">
                  {access ? (
                    <Link to={createPageUrl(`LearningPathDetail?id=${path.id}`)}>
                      <Button className="w-full bg-slate-900 hover:bg-slate-800 text-white">
                        Start Path <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  ) : (
                    <Link to={createPageUrl('Subscription')}>
                      <Button className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white">
                        <Crown className="w-4 h-4 mr-2" /> Unlock Premium
                      </Button>
                    </Link>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {paths.length === 0 && (
        <div className="text-center py-20 bg-white rounded-xl border-2 border-dashed border-slate-300">
          <MapPin className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 text-lg">No learning paths available yet</p>
          <p className="text-slate-500 text-sm mt-2">Check back soon for structured learning journeys</p>
        </div>
      )}
    </div>
  );
}
