# Release tooling (Windows)

This folder contains PowerShell tooling to generate a clean, deployable ZIP from the repo.

- Excludes: `.git/`, `node_modules/`, `dist/`, `build/`, `coverage/` and common caches
- Produces:
  - `release/<project>_<version>_<timestamp>.zip`
  - `release/<zip>.sha256.txt`
  - `release/BUILDINFO.json` (also included inside the ZIP)

## Build

From repo root (PowerShell):

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\release\build-release.ps1 -Version "v9.1"
```
