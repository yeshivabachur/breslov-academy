<# 
Build a clean release ZIP (Windows PowerShell 5.1+ / PowerShell 7+).

Usage (from repo root):
  powershell -ExecutionPolicy Bypass -File .\tools\release\build-release.ps1 -Version "v9.1"

Outputs:
  .\release\<project>_<version>_<timestamp>.zip
  .\release\<zip>.sha256.txt
  .\release\BUILDINFO.json
#>

param(
  [string]$Project = "breslov-academy",
  [string]$Version = "v9.1",
  [string]$OutDir = "release"
)

$ErrorActionPreference = "Stop"

function New-EmptyDir([string]$Path) {
  if (Test-Path $Path) { Remove-Item -Recurse -Force $Path }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

$repoRoot = (Resolve-Path ".").Path
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outPath = Join-Path $repoRoot $OutDir
New-Item -ItemType Directory -Force -Path $outPath | Out-Null

$staging = Join-Path $outPath "_staging"
New-EmptyDir $staging

# Copy repo to staging (exclude bulky / generated / secret-ish paths)
$excludeDirs = @(
  ".git",
  "node_modules",
  "dist",
  "build",
  "coverage",
  ".next",
  ".cache",
  ".turbo",
  ".parcel-cache",
  ".vercel"
)

# Robocopy is fast and supports exclusions.
# /E includes empty dirs; /XD excludes directories; /XF excludes files.
$xd = @()
foreach ($d in $excludeDirs) { $xd += (Join-Path $repoRoot $d) }

$xf = @("*.log","*.tmp","*.DS_Store")
$robolog = Join-Path $outPath ("robocopy_{0}.log" -f $timestamp)

& robocopy $repoRoot $staging /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP /LOG:$robolog /XD $xd /XF $xf | Out-Null

# Try to capture git commit (if available)
$gitCommit = $null
try {
  $gitCommit = (& git rev-parse HEAD 2>$null).Trim()
} catch { }

$nodeVersion = $null
try { $nodeVersion = (& node -v 2>$null).Trim() } catch { }
$npmVersion = $null
try { $npmVersion = (& npm -v 2>$null).Trim() } catch { }

$buildInfo = [ordered]@{
  project = $Project
  version = $Version
  timestamp = (Get-Date).ToString("o")
  git_commit = $gitCommit
  node = $nodeVersion
  npm = $npmVersion
  host = $env:COMPUTERNAME
  os = (Get-CimInstance Win32_OperatingSystem).Caption
}

$buildInfoPath = Join-Path $outPath "BUILDINFO.json"
$buildInfo | ConvertTo-Json -Depth 6 | Out-File -Encoding UTF8 $buildInfoPath

# Also include BUILDINFO.json inside the ZIP
Copy-Item $buildInfoPath (Join-Path $staging "BUILDINFO.json") -Force

$zipName = "{0}_{1}_{2}.zip" -f $Project, $Version, $timestamp
$zipPath = Join-Path $outPath $zipName

if (Test-Path $zipPath) { Remove-Item -Force $zipPath }

# Compress-Archive doesn't support exclude, but we've already staged a clean tree.
Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zipPath -Force

# SHA256 checksum
$hash = Get-FileHash -Algorithm SHA256 -Path $zipPath
$shaPath = "$zipPath.sha256.txt"
("{0}  {1}" -f $hash.Hash.ToLower(), (Split-Path $zipPath -Leaf)) | Out-File -Encoding ASCII $shaPath

Write-Host "✅ Release ZIP created:"
Write-Host "   $zipPath"
Write-Host "✅ SHA256:"
Write-Host "   $shaPath"
Write-Host "✅ Build info:"
Write-Host "   $buildInfoPath"

# Cleanup staging
Remove-Item -Recurse -Force $staging
